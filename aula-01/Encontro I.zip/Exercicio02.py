﻿print("--- SmartFinance: Meu Primeiro Caixa ---")

# Exercício prático:
# 1) Peça ao usuário o valor do salário e o valor das despesas.
# 2) Calcule o saldo final: salário - despesas.
# 3) Exiba o saldo com duas casas decimais.
# 4) Informe se o saldo está positivo, zero ou negativo.
# 5) (Bônus) leia uma despesa extra e atualize o saldo.

try:
    salario = float(input("Digite o valor do seu salário: "))
    despesas = float(input("Digite o valor das suas contas: "))
    despesa_extra = float(input("Digite o valor de uma despesa extra (ou 0 se não houver): "))
except ValueError:
    print("Entrada inválida. Digite um número válido, usando ponto para decimais.")
else:
    saldo_final = salario - despesas - despesa_extra
    print(f"Seu saldo final é de: R$ {saldo_final:.2f}")

    if saldo_final > 0:
        print("Parabéns! Você ficou no positivo.")
    elif saldo_final == 0:
        print("Atenção: seu saldo ficou zerado.")
    else:
        print("Atenção: saldo negativo. Reveja suas despesas.")
