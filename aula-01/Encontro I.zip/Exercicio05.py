﻿print("--- SmartFinance: Orçamento Mensal Avançado ---")

# Exercício prático:
# 1) Peça ao usuário o valor do salário mensal.
# 2) Peça quatro despesas: aluguel, alimentação, transporte e lazer.
# 3) Peça uma meta de economia mensal.
# 4) Calcule total de despesas, saldo e porcentagens.
# 5) Mostre se a meta de economia foi atingida e sugira cortes se necessário.

try:
    salario = float(input("Digite o valor do seu salário mensal: "))
    aluguel = float(input("Digite o valor do aluguel: "))
    alimentacao = float(input("Digite o valor da alimentação: "))
    transporte = float(input("Digite o valor do transporte: "))
    lazer = float(input("Digite o valor do lazer: "))
    meta_economia = float(input("Digite o valor da sua meta de economia mensal: "))
except ValueError:
    print("Entrada inválida. Digite apenas números válidos, usando ponto para decimais.")
else:
    despesas = {
        "Aluguel": aluguel,
        "Alimentação": alimentacao,
        "Transporte": transporte,
        "Lazer": lazer,
    }
    total_despesas = sum(despesas.values())
    saldo = salario - total_despesas

    def explicar_orcamento(salario, despesas, total_despesas, saldo, meta_economia):
        linhas = []
        linhas.append(f"Você recebe R$ {salario:.2f} por mês e gastou R$ {total_despesas:.2f} no total.")
        if salario != 0:
            linhas.append(f"Isso representa {total_despesas / salario * 100:.1f}% do seu salário.")

        if saldo > 0:
            linhas.append("Seu orçamento está positivo, então sobra dinheiro após pagar as despesas.")
        elif saldo == 0:
            linhas.append("Seu orçamento fechou no zero, então não sobrou nem faltou dinheiro.")
        else:
            linhas.append("Seu orçamento está negativo, ou seja, você gastou mais do que ganha.")

        maior_despesa = max(despesas, key=despesas.get)
        linhas.append(f"A maior despesa foi {maior_despesa} com R$ {despesas[maior_despesa]:.2f}.")

        if meta_economia > 0:
            if saldo >= meta_economia:
                linhas.append(f"Você atingiu a meta de economia de R$ {meta_economia:.2f}.")
            else:
                linhas.append(f"Faltam R$ {meta_economia - saldo:.2f} para alcançar a meta de economia.")

        for nome, valor in despesas.items():
            if salario != 0:
                pct = valor / salario * 100
                if pct >= 30:
                    linhas.append(f"Atenção: {nome} consome {pct:.1f}% do salário, que é uma parte alta do seu orçamento.")
        return "\n".join(linhas)

    print(f"\nTotal de despesas: R$ {total_despesas:.2f}")
    print(f"Saldo final: R$ {saldo:.2f}")
    print(f"Meta de economia: R$ {meta_economia:.2f}\n")

    for nome, valor in despesas.items():
        porcentagem = (valor / salario * 100) if salario != 0 else 0
        print(f"{nome}: R$ {valor:.2f} ({porcentagem:.1f}% do salário)")

    if saldo >= meta_economia:
        print("\nParabéns! Você está no caminho para atingir sua meta de economia.")
    else:
        falta = meta_economia - saldo
        print(f"\nAtenção: você ainda precisa economizar R$ {falta:.2f} para atingir a meta.")

        maior_despesa = max(despesas, key=despesas.get)
        print(f"Considere reduzir a despesa de {maior_despesa} para melhorar seu saldo.")

    print("\n--- Explicação dinâmica ---")
    print(explicar_orcamento(salario, despesas, total_despesas, saldo, meta_economia))
