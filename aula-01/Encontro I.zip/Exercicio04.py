print("--- SmartFinance: Planejamento de Despesas ---")

# Exercício prático:
# 1) Peça ao usuário o valor do salário mensal.
# 2) Peça os valores de três despesas: aluguel, alimentação e transporte.
# 3) Calcule o total de despesas e o saldo restando do salário.
# 4) Mostre a porcentagem que cada despesa representa do salário.
# 5) Informe se o usuário alcançou a meta de poupança de 20% do salário.

try:
    salario = float(input("Digite o valor do seu salário mensal: "))
    aluguel = float(input("Digite o valor do aluguel: "))
    alimentacao = float(input("Digite o valor da alimentação: "))
    transporte = float(input("Digite o valor do transporte: "))
except ValueError:
    print("Entrada inválida. Digite valores numéricos válidos, usando ponto para decimais.")
else:
    total_despesas = aluguel + alimentacao + transporte
    saldo = salario - total_despesas
    poupança_meta = salario * 0.20

    def porcentagem(valor, base):
        return (valor / base * 100) if base != 0 else 0

    print(f"\nTotal de despesas: R$ {total_despesas:.2f}")
    print(f"Saldo final: R$ {saldo:.2f}")
    print(f"Aluguel representa {porcentagem(aluguel, salario):.1f}% do salário.")
    print(f"Alimentação representa {porcentagem(alimentacao, salario):.1f}% do salário.")
    print(f"Transporte representa {porcentagem(transporte, salario):.1f}% do salário.")

    if saldo >= poupança_meta:
        print("Parabéns! Você atingiu a meta de poupança de 20% do salário.")
    else:
        print("Atenção: você não atingiu a meta de poupança de 20% do salário.")
        print(f"Faltam R$ {poupança_meta - saldo:.2f} para chegar na meta.")
