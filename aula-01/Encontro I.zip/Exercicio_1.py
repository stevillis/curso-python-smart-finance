print("--- SmartFinance: Meu Primeiro Caixa ---")

# Exemplo de uso:
# Entrada:
#   2500.50
#   1800.75
# Saída:
#   Seu saldo final é de: R$ 699.75

try:
    receita = float(input("Digite o valor do seu salário: "))
    despesa = float(input("Digite o valor das suas contas: "))
except ValueError:
    print("Entrada inválida. Digite um número válido, usando ponto para decimais.")
else:
    saldo_final = receita - despesa
    print("Seu saldo final é de: R$", saldo_final)